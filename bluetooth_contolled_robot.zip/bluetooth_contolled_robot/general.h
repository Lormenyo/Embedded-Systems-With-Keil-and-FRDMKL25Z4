#include <MKL25Z4.H>
#include <string.h>
#include <stdio.h>
#define MASK(X)		(1<<X)
#define ONE_SECOND 1000

void systick_clock(void);
unsigned long millis(void);



