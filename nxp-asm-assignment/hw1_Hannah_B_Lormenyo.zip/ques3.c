
//int specialFxn(int n){
//	int i = 0;
//	while(n != 0){
//	       i = i + n;
//	       n--;
//		}
//		n = i;

//  return n ;

//}
